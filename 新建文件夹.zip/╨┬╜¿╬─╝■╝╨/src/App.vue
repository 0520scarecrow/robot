<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style scope>
html,
body {
  height: 100%;
  min-height: 100%;
}
* {
  margin: 0;
  padding: 0;
}
#app {
  height: 100%;
  min-height: 100%;
  background-color: #d0e4ff;
  padding: 10px;
}
</style>
